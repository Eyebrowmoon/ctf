#ifndef __SCRIPT__
#define __SCRIPT__

#include <stdio.h>
#include "astparser.h"

char* fgets_eof(char* buf, size_t len);
int execute(char* c);

#endif
